g++ main.cpp -lglut -lGLU -lGL -o main
